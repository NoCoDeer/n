<?php

namespace ElementorNokri\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Job_Req_Sec extends Widget_Base
{

    public function get_name()
    {
        return 'job-req-sec';
    }

    public function get_title()
    {
        return __('Job Request', 'nokri-elementor');
    }

    public function get_icon()
    {
        return 'eicon-posts-group';
    }

    public function get_categories()
    {
        return ['nokritheme'];
    }

    public function get_script_depends()
    {
        return [''];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        /* for About Us tab */
        $this->start_controls_section(
            'basic_section',
            [
                'label' => __('Basic', 'nokri-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'jb_name',
            [
                'label' => __('Name', 'nokri-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'jb_email',
            [
                'label' => __('Email', 'nokri-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'jb_det_file',
            [
                'label' => __('Job Detail File', 'nokri-elementor'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                "description" => esc_html__('263x394', 'nokri-elementor'),
            ]
        );
        $this->add_control(
            'jb_desc',
            [
                'label' => __('Description', 'nokri-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        // get our input from the widget settings.
        $settings = $this->get_settings_for_display();
        $user_id = get_current_user_id();
        $user_role = get_user_meta($user_id, '_sb_reg_type', true);
        global $nokri;
        //For countries

        $atts = $settings;

        extract($settings);
        require trailingslashit(get_template_directory()) . "inc/theme-shortcodes/shortcodes/layouts/header_layout.php";

        if (!is_user_logged_in()) {
            echo nokri_redirect(home_url('/nokri/signin/'));
        }

        if ($nokri['emp_jb_req'] == true) {
            /* Main heading */
            $basic_heading = (isset($basic_heading) && $basic_heading != "") ? '<h1>' . $basic_heading . '</h1>' : "";
            /* Main details */
            $basic_details = (isset($basic_details) && $basic_details != "") ? '<p>' . $basic_details . '</p>' : "";
            /* Section heading */
            $page_heading = (isset($page_heading) && $page_heading != "") ? '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="post-job-heading"><h3>' . $page_heading . '</h3></div></div>' : "";
            /* Social heading */
            $social_heading = (isset($social_heading) && $social_heading != "") ? '<div class="post-job-heading"><h3>' . $social_heading . '</h3></div>' : "";
            /* Social details */
            $social_details = (isset($social_details) && $social_details != "") ? '<div class="form-group"><p>' . $social_details . '</p></div>' : "";
            /* already acount */
            $already_acount = (isset($already_acount) && $already_acount != "") ? $already_acount : "";
            /* signup */
            $signup_text = (isset($signup_text) && $signup_text != "") ? $signup_text : "";
            /* submit button */
            $submit_button = (isset($submit_button) && $submit_button != "") ? $submit_button : "";

            $remember_me = (isset($remember_me) && $remember_me != "") ? $remember_me : "";

            $show_password = (isset($show_password) && $show_password != "") ? $show_password : "";



            global $nokri;
            $social_login = '';

            /* Social Login Miniorange Compatibility */
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
            if (is_plugin_active('miniorange-login-openid/miniorange_openid_sso_settings.php')) {
?>
                <div class="form-group">
                    <?php
                    delete_option('mo_openid_login_widget_customize_text'); // remove the connect with text
                    $social_login .= do_shortcode('[miniorange_social_login shape="longbuttonwithtext" view="horizontal" appcnt="3" theme="default" space="35" width="270" height="40" color="000000"]');
                    ?>
                </div>
<?php
            }

            $authentication = new \authentication();
            $code = time();
            $_SESSION['sb_nonce'] = $code;

            /* Background Image */
            $bg_img = '';
            if (isset($basic_bg_img['url'])) {
                $bgImageURL = $basic_bg_img['url'];
                $bg_img = ($bgImageURL != "") ? ' \\s\\t\\y\\l\\e="background: rgba(0, 0, 0, 0.6) url(' . $bgImageURL . ') 0 0 no-repeat; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; background-position: center center; background-attachment:scroll;"' : "";
            }

            /* Sidebar */
            $side_bar = (isset($is_show_side) && $is_show_side != "") ? $is_show_side : true;
            $side_bar_html = '';
            $col_sizes = 'col-lg-6 col-md-6 col-sm-6 col-xs-12 col-md-offset-3 col-lg-offset-3';
            $col_sizes2 = 'col-lg-12 col-md-12 col-sm-12 col-xs-12';
            if ($side_bar == 'yes') {
                $col_sizes = 'col-lg-10 col-md-10 col-sm-12 col-xs-12 col-md-offset-1 col-lg-offset-1';
                $col_sizes2 = 'col-lg-7 col-md-7 col-sm-12 col-xs-12 ';
                $side_bar_html = '<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 nopadding">
                <div class="n-page-right-side">
                    
				</div>			  
                </div>';
            }
            echo
            '<div class="custom-modal">
         <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog modal-lg">
            </div>
         </div>
        </div>
        <section class="n-pages-breadcrumb" ' . str_replace('\\', "", $bg_img) . '>
        <div class="container">
            <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-2">
                <div class="n-breadcrumb-info">
                    ' . ($basic_heading . $basic_details) . '
                </div>
            </div>
            </div>
        </div>
        </section>
        <section class="n-job-pages-section">
                <div class="container">
                    <div class="row">
                    <div class="' . esc_attr($col_sizes) . '">
                        <div class="row">
                            <div class="n-job-pages">
                                <div class="' . esc_attr($col_sizes2) . '">
                                <div class="row">
                                    <div class="n-page-left-side">
                                    <form id="jb_request_submit">
                                        <div class="modal-body">
                                            <div class="form-group">
                                            <label>' . __('Enter your Name', 'nokri') . '</label>
                                            <input type="name" data-parsley-required="true" data-parsley-error-message="' . esc_html__('Please enter name', 'nokri') . '" placeholder="' . esc_html__('Your Name', 'nokri') . '" name="jb_user" id="jb_user"  class="form-control">
                                            </div> 
                                            <div class="form-group">
                                            <label>' . __('Enter your email', 'nokri') . '</label>
                                            <input placeholder="' . esc_html__('Your Email', 'nokri') . '" class="form-control" type="email" data-parsley-required="true" data-parsley-error-message="' . esc_html__('Please enter Valid email.', 'nokri') . '" name="jb_email" id="jb_email">
                                            </div>                            
                                            <div class="form-group">
                                            <label>' . __('Enter Job Detail File', 'nokri') . '</label>
                                            <input type="file" data-parsley-required="true" data-parsley-error-message="' . esc_html__('Please Upload file', 'nokri') . '" class="" name="jb_file" id="jb_file">
                                            </div>
                                            <div class="form-group">
                                            <label>' . __('Description (Optional)', 'nokri') . '</label>
                                            <textarea rows="6" class="form-control"   name="jb_det"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">                                     
                                                <button class="btn n-btn-flat" type="submit" id="jb_submit">' . __('Submit', 'nokri') . '</button>                                              
                                                <input type="hidden"  value="' . esc_url(get_the_permalink()) . '"  id="sign_in_page">
                                        </div>
                                        </form>
                                    </div>
                                </div>
                                </div>
                                
                                ' . $side_bar_html . '
                                
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
        </section>';
        } else {
            // echo '<div class="container"><br>Admin Not Allowed To Request a job.</div>';
            echo '<div class="alert alert-info alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <strong>' . esc_html__("Information ! ", "nokri") . '</strong>' . esc_html__("Admin Not Allowed To Request a Job", "nokri") . '
                </div>';
        }
    }

    /**
     * Render the widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function content_template()
    {
    }
}
