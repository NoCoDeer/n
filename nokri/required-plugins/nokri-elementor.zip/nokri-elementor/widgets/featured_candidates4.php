<?php

namespace ElementorNokri\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Featured_Candidates4 extends Widget_Base {

    public function get_name() {
        return 'featured_candidates_4';
    }

    public function get_title() {
        return __('Featured candidates 4', 'nokri-elementor');
    }

    public function get_icon() {
        return 'eicon-posts-group';
    }

    public function get_categories() {
        return ['nokritheme'];
    }

    public function get_script_depends() {
        return [''];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {
        /* for About Us tab */
        $this->start_controls_section(
                'basic_section',
                [
                    'label' => __('Basic)', 'nokri-elementor'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
        );

        $this->add_control(
                'sec_bg_clr',
                [
                    'label' => __('Section Backgroun color', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => array(
                        '' => esc_html__('Select Option', 'nokri-elementor'),
                        'light-grey' => esc_html__('Sky BLue', 'nokri-elementor'),
                        '' => esc_html__('White', 'nokri-elementor'),
                    ),
                ]
        );
        $this->add_control(
                'section_title',
                [
                    'label' => __('Section Title', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                ]
        );
        $this->add_control(
                'section_desc',
                [
                    'label' => __('Section Description', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                ]
        );



        $this->add_control(
                'candidate_type',
                [
                    'label' => __('Select Candidate type', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => array(
                        '' => esc_html__('Select Option', 'nokri-elementor'),
                        '1' => esc_html__('Featured', 'nokri-elementor'),
                        '0' => esc_html__('Simple', 'nokri-elementor'),
                    ),
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        // get our input from the widget settings.
        $settings = $this->get_settings_for_display();
        global $nokri;
        //For countries

        $atts = $settings;

        extract($atts);
        $featured_cand = '';
        if (isset($candidate_type) && $candidate_type == "1") {
            $featured_cand = array(
                'key' => '_is_candidate_featured',
                'value' => '1',
                'compare' => '='
            );
        }

        $args = array();
        if (!empty($featured_cand)) {
            $args = array(
                'order' => 'DESC',
                'meta_query' => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_sb_reg_type',
                        'value' => '0',
                        'compare' => '='
                    ),
                    $featured_cand,
                ),
            );
        }
        $user_query = new \WP_User_Query($args);
        $authors = $user_query->get_results();
        $required_user_html = $featured = '';
        if (!empty($authors)) {
            $num = 1;
            foreach ($authors as $author) {
                $cand_address = '';
                $user_id = $author->ID;
                $user_name = $author->display_name;
                $cand_add = get_user_meta($user_id, '_cand_address', true);
                $cand_head = get_user_meta($user_id, '_user_headline', true);
                $featured_date = get_user_meta($user_id, '_candidate_feature_profile', true);
                $salary_range = get_user_meta($user_id, '_cand_salary_range', true);
                $salary_curren = get_user_meta($user_id, '_cand_salary_curren', true);
                $today = date("Y-m-d");
                $expiry_date_string = strtotime($featured_date);
                $today_string = strtotime($today);
                if ($today_string > $expiry_date_string) {
                    delete_user_meta($user_id, '_candidate_feature_profile');
                    delete_user_meta($user_id, '_is_candidate_featured');
                }
                if ($cand_head != '') {
                    $cand_head = '<p>' . $cand_head . '</p>';
                }
                if ($cand_add != '') {
                    $cand_address = '<p><i class="fa fa-map-marker"></i>'.' ' . $cand_add . '</p>';
                }
                /* Getting Star */
                if (isset($candidate_type) && $candidate_type == "1") {
                    $featured = '<a href=""><i class="fa fa-star rate-icon"></i></a>';
                };

                global $nokri;
                $author_id = get_query_var('author');

                if ($author_id == "") {
                    $author_id = isset($_GET["user_id"]) ? $_GET["user_id"] : "";
                }

                if (isset($_GET['candidate-page']) && $_GET['candidate-page'] == "my_ratings") {
                    $author_id = get_current_user_id();
                }

                $comment_count = nokri_employer_review_count($author_id);
                //$current_user_id = get_current_user_id();
                $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
                $limit = isset($nokri['cand_reviews_count_limit']) ? $nokri['cand_reviews_count_limit'] : 5;
                if (isset($limit) && $limit != "") {
                    $pages = ceil($comment_count / $limit);
                }
                $args = array(
                    'user_id' => $author_id,
                    'type' => 'dealer_review',
                    'order' => 'DESC',
                    'paged' => $paged,
                    'number' => $limit,
                );

                $get_rating = get_comments($args);

                if (count((array) $get_rating) > 0) {
                    foreach ($get_rating as $get_ratings) {

                        $comment_ids = $get_ratings->comment_ID;
                        $service_stars = get_comment_meta($comment_ids, '_rating_service', true);
                        $process_stars = get_comment_meta($comment_ids, '_rating_proces', true);
                        $selection_stars = get_comment_meta($comment_ids, '_rating_selection', true);
                        //$comment_title = get_comment_meta($comment_ids, '_rating_title', true);

                        $single_avg = 0;
                        $total_stars = $service_stars + $process_stars + $selection_stars;

                        if (isset($total_stars) && $total_stars != '') {
                            $single_avg = round($total_stars / "3", 1);
                            $star_rat = '';
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= ($single_avg)) {
                                    $star_rat .= '<i class="fa fa-star fill"></i>';
                                } else {
                                    $star_rat .= '<i class="fa fa-star unfill">';
                                }
                            }
                        }
                    }
                }

                /* Getting Candidates Skills  */
                $skill_tags = nokri_get_candidates_skills_new($user_id, '');
                $required_user_html .= '<div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                                    <div class="profile-card">
                                        <div class="prf-meta">
                                            <img src="' . nokri_get_user_profile_pic($user_id, '_cand_dp') . '" alt="' . esc_attr__('image', 'nokri-elementor') . '">                                            
                                            <div class="rating">
                                                ' . $star_rat . '
                                            </div>                                           
                                            <a href="' . esc_url(get_author_posts_url($user_id)) . '"><h4 class="name">' . $user_name . '</h4></a>
                                            <span class="skill">' . $cand_head . '</span>
                                                <span class="location"> ' . $cand_address . '</span>                                         
                                            <ul>                                               
                                                    ' . $skill_tags . '
                                            </ul>
                                            <div class="favrt-outer">
                                                <a href="javascript:void(0)" class="saving_resume" data-cand-id="' . esc_attr($user_id) . '"><i class="fa fa-heart"></i></a>
                                            </div>
                                            <div class="rate-box"></div>
                                            ' . $featured . '
                                        </div>
                                        <div class="prf-btn">
                                            <a class="view-prf" href="' . esc_url(get_author_posts_url($user_id)) . '">' . esc_html__('View Profile', 'nokri') . '</a>
                                        </div>
                                        </div>
                                    </div>';
                if ($num % 3 == 0) {
                    $required_user_html .= '<div class="clearfix"></div>';
                }
                $num++;
            }
        }

        /* Section clr */
        $section_clr = (isset($sec_bg_clr) && $sec_bg_clr != "") ? $sec_bg_clr : "";
        /* Section title */
        $section_title = (isset($section_title) && $section_title != "") ? '' . $section_title . '' : "";
        /* Section description */
        $section_descrp = (isset($section_desc) && $section_desc != "") ? '' . $section_desc . '' : "";
        echo '<section class="featured-candidates"' . $section_clr . '>
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                            <div class="nokri-main-meta"> 
                                <h2 class="main-heading">' . $section_title . '</h2>
                                <p class="main-txt">' . $section_descrp . '</p>
                            </div>
                        </div>
                    </div>
                <div class="row">
                    
                        ' . $required_user_html . '
                    
                </div>
            </div>
        </section>';
    }

    /**
     * Render the widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function content_template() {
        
    }

}
