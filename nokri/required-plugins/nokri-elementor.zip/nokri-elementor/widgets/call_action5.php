<?php

namespace ElementorNokri\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Call_Action5 extends Widget_Base {

    public function get_name() {
        return 'call-to-action5';
    }

    public function get_title() {
        return __('Call To Action Latest', 'nokri-elementor');
    }

    public function get_icon() {
        return 'eicon-posts-group';
    }

    public function get_categories() {
        return ['nokritheme'];
    }

    public function get_script_depends() {
        return [''];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {
        /* for About Us tab */
        $this->start_controls_section(
                'basic_section',
                [
                    'label' => __('Basic', 'nokri-elementor'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
        );
        $this->add_control(
                'sec_bg_img',
                [
                    'label' => __('Background Image', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    "description" => esc_html__('1920 x 473', 'nokri-elementor'),
                ]
        );
        $this->add_control(
                'section_img',
                [
                    'label' => __('Section Image', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    "description" => esc_html__('692 x 463', 'nokri-elementor'),
                ]
        );
        $this->add_control(
                'heading',
                [
                    'label' => __('Section Heading', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                ]
        );
        $this->add_control(
                'description',
                [
                    'label' => __('Section Description', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                ]
        );
        $this->add_control(
                'btn_txt',
                [
                    'label' => __('Button Text', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                ]
        );
        $this->add_control(
                'link',
                [
                    'label' => __('Link', 'nokri-elementor'),
                    'type' => \Elementor\Controls_Manager::URL,
                    'placeholder' => __('https://your-link.com', 'nokri-elementor'),
                    'show_external' => true,
                    'default' => [
                        'url' => '#',
                        'is_external' => true,
                        'nofollow' => true,
                    ],
                ]
        );
        $this->end_controls_section();
    }
    protected function render() {
        // get our input from the widget settings.
        $settings = $this->get_settings_for_display();
        global $nokri;
        //For countries
        $atts = $settings;
        extract($settings);
        
        $stories_html = "";
        if (isset($atts['numbers']) && $atts['numbers'] != '') {
            $rows_story = $atts['numbers'];
            if ((array) count($rows_story) > 0) {
                foreach ($rows_story as $row_story) {
                    /* Title */
                    $astory_title = (isset($row_story['title']) && $row_story['title'] != "") ? ' <p>' . $row_story['title'] . '</p>' : "";
                    /* Story Description */
                    $astory_no = (isset($row_story['number']) && $row_story['number'] != "") ? '<span class="counter" data-to="' . $row_story['number'] . '" data-time="2000" data-fps="20"></span>' : "";
                    /* Story Html */
                    $stories_html .= '<li> 
					<div class="counter-js">
                                            ' . $astory_no . '
                                            ' . $astory_title . '
					</div>
                                    </li>';
                }
            }
        }
        /* Section Tagline */
        $section_tagline = (isset($tagline) && $tagline != "") ? '<span>' . $tagline . '</span>' : "";
        /* Section Heading */
        $section_heading = (isset($heading) && $heading != "") ? '<h3>' . $heading . '</h3>' : "";
        /* Section Details */
        $section_desc = (isset($description) && $description != "") ? '<p>' . $description . '</p>' : "";
        /* Background Image */
        /* Link */
        $btn = '';

        if (isset($btn_txt)) {
            $btn = elementor_ThemeBtn($link, 'btn n-btn-flat btn-mid', false, '', '', $btn_txt);
        }
        $bg_img = '';
        if (isset($sec_bg_img['url'])) {
            $bgImageURL = $sec_bg_img['url'];
            $bg_img = ( $bgImageURL != "" ) ? ' \\s\\t\\y\\l\\e="background: url(' . $bgImageURL . ') no-repeat; -webkit-background-size: contain; -moz-background-size: cover; -o-background-size: contain; background-size: contain; background-position: center center; background-attachment:scroll;"' : "";
        }
        /* Section Image */
        $sec_img = '';
        if (isset($section_img['url'])) {

            $img_thumb = $section_img['url'];
            $sec_img = '<div class="n-8-img"><img src="' . esc_url($img_thumb) . '" alt="' . esc_attr__('image', 'nokri-elementor') . '" class="img-responsive"></div>';
        }
        echo '<section class="our-resources"' . str_replace('\\', "", $bg_img) . '>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                        <div class="left-cont">
                            <h3 class="title">' . $section_heading . '</h3>
                                ' . $section_desc . '
                            <div class="main-btn">
                               ' . $btn . '
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                        <div class="main-img">
                            <img src="' . $img_thumb . '" alt="' . esc_attr__('image', 'nokri-elementor') . '">
                        </div>
                    </div>
                </div>
            </div>
        </section>';
    }

    /**
     * Render the widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function content_template() {
        
    }

}
